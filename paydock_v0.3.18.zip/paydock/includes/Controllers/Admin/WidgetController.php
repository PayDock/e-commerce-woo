<?php

namespace Paydock\Controller\Admin;

class WidgetController
{

}
