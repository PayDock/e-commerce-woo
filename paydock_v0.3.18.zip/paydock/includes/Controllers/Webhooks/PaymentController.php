<?php

namespace Paydock\Controller\Webhooks;

class PaymentController
{

}
