<?php
/** 
 * Template: hide-refund-button
 */
?>
<style>
	.refund-items,
	.order_refund {
		display: none !important;
	}
</style>