<?php

namespace PowerBoard\Controller\Admin;

class SettingsController
{

}
