<?php

namespace PowerBoard\Services;

class LoggerService
{

}
