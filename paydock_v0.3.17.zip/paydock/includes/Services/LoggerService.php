<?php

namespace Paydock\Services;

class LoggerService
{

}
