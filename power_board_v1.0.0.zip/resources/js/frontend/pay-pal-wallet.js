import walletsForm from "../includes/wallets-form";

walletsForm(
    'pay-pal',
    'Power Board PayPal',
    'powerBoardWalletPayPalButton',
    [
        'first_name',
        'last_name',
        'email',
        'address_1',
        'city',
        'state',
        'country',
        'postcode',
    ]
);
