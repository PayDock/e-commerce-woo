import walletsForm from "../includes/wallets-form";

walletsForm(
    'google-pay',
    'Power Board Google Pay',
    'powerBoardWalletGooglePayButton',
    [
        'first_name',
        'last_name',
        'email',
        'address_1',
        'city',
        'state',
        'country',
        'postcode',
    ]
);
