<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once "vendor/autoload.php";

PowerBoard\Hooks\UninstallHook::handle();
