<?php

namespace Paydock\Services\ProcessPayment;

use Exception;
use Paydock\Helpers\ArgsForProcessPayment;
use Paydock\Repositories\UserCustomerRepository;
use Paydock\Services\SDKAdapterService;

class ApmProcessor
{
    const CHARGE_METHOD = 'charge';
    const CUSTOMER_CHARGE_METHOD = 'customerCharge';
    const AUTHORISE_CHARGE_METHOD = 'authoriseCharge';
    const FRAUD_CHARGE_METHOD = 'fraudCharge';
    const FRAUD_PASSIVE_CHARGE_METHOD = 'authoriseFraudCharge';
    const FRAUD_IN_REVIEW_PASSIVE_CHARGE_METHOD = 'authoriseFraudChargeInReview';
    const ALLOWED_METHODS = [
        self::CHARGE_METHOD,
        self::CUSTOMER_CHARGE_METHOD,
        self::AUTHORISE_CHARGE_METHOD,
        self::FRAUD_CHARGE_METHOD,
        self::FRAUD_PASSIVE_CHARGE_METHOD,
        self::FRAUD_IN_REVIEW_PASSIVE_CHARGE_METHOD
    ];

    protected array $args = [];
    protected array $tokenData = [];
    private ?string $runMethod;

    public function __construct(array $args = [])
    {
        $this->args = ArgsForProcessPayment::prepare($args);
    }

    public function run(): array
    {
        $this->setRunMethod();

        if (!in_array($this->runMethod, self::ALLOWED_METHODS)) {
            throw new Exception(__('Undefined run method', PAY_DOCK_TEXT_DOMAIN));
        }

        return call_user_func([$this, $this->runMethod]);
    }

    private function setRunMethod()
    {
        switch (true) {
            case $this->args['apmsavecard']:
                $this->runMethod = self::CUSTOMER_CHARGE_METHOD;
                break;
            default:
                $this->runMethod = self::CHARGE_METHOD;
        }
    }

    public function getRunMethod()
    {
        return $this->runMethod;
    }

    private function charge(): array
    {
        $chargeArgs = [
            'amount' => $this->args['amount'],
            'currency' => strtoupper(get_woocommerce_currency()),
            'token' => $this->args['paymentsourcetoken']
        ];

        return SDKAdapterService::getInstance()->createCharge($chargeArgs);
    }

    private function customerCharge(): array
    {
        $customerArgs = [
            'token' => $this->args['paymentsourcetoken']
        ];

        $customer = SDKAdapterService::getInstance()->createCustomer($customerArgs);

        if (!empty($customer['error']) || empty($customer['resource']['data']['_id'])) {
            $message = !empty($customer['error']['message']) ? ' ' . $customer['error']['message'] : '';
            throw new Exception(__('Can\'t create Paydock customer.' . $message, PAY_DOCK_TEXT_DOMAIN));
        }

        $res = null;
        if ($this->args['apmsavecardchecked']) {
            $res = (new UserCustomerRepository)->saveUserCustomer($customer['resource']['data']);
        }

        $customer_id = $customer['resource']['data']['_id'];

        return SDKAdapterService::getInstance()->createCharge([
            'amount' => $this->args['amount'],
            'currency' => strtoupper(get_woocommerce_currency()),
            'customer_id' => $customer_id,
        ]);
    }

    private function authoriseCharge(): array
    {
        $chargeArgs = [
            'amount' => $this->args['amount'],
            'currency' => strtoupper(get_woocommerce_currency()),
            'capture' => false,
            'token' => $this->args['paymentsourcetoken']
        ];

        $charge = SDKAdapterService::getInstance()->createCharge($chargeArgs);

        if (!empty($charge['error']) || empty($charge['resource']['data']['_id'])) {
            $message = SDKAdapterService::getInstance()->errorMessageToString($charge);
            throw new Exception(__('Can\'t charge.' . $message, PAY_DOCK_TEXT_DOMAIN));
        }

        return SDKAdapterService::getInstance()->capture([
            'charge_id' => $charge['resource']['data']['_id']
        ]);
    }

    private function fraudCharge(): array
    {
        $chargeArgs = [
            'amount' => $this->args['amount'],
            'currency' => strtoupper(get_woocommerce_currency()),
            'capture' => true,
            'token' => $this->args['paymentsourcetoken'],
            'fraud' => [
                'token' => $this->args['fraud_token'],
                'service_id' => $this->args['fraud_service_id'],
                'mode' => 'active',
                'data' => [
                    'transaction' => [
                        'billing' => [
                            'customerEmailAddress' => $this->args['email'] ?? ''
                        ]
                    ]
                ]
            ]
        ];

        return SDKAdapterService::getInstance()->createCharge($chargeArgs);
    }

    private function authoriseFraudCharge(): array
    {
        $chargeArgs = [
            'amount' => $this->args['amount'],
            'currency' => strtoupper(get_woocommerce_currency()),
            'capture' => false,
            'token' => $this->args['paymentsourcetoken'],
            'fraud' => [
                'token' => $this->args['fraud_token'],
                'service_id' => $this->args['fraud_service_id'],
                'mode' => 'passive',
                'data' => [
                    'transaction' => [
                        'billing' => [
                            'customerEmailAddress' => $this->args['email'] ?? ''
                        ]
                    ]
                ]
            ]
        ];

        $charge = SDKAdapterService::getInstance()->createCharge($chargeArgs);

        if (!empty($charge['error']) || empty($charge['resource']['data']['_id'])) {
            $message = SDKAdapterService::getInstance()->errorMessageToString($charge);
            throw new Exception(__('Can\'t charge.' . $message, PAY_DOCK_TEXT_DOMAIN));
        }

        return SDKAdapterService::getInstance()->capture([
            'charge_id' => $charge['resource']['data']['_id']
        ]);
    }

    private function authoriseFraudChargeInReview(): array
    {
        $chargeArgs = [
            'amount' => $this->args['amount'],
            'currency' => strtoupper(get_woocommerce_currency()),
            'capture' => false,
            'token' => $this->args['paymentsourcetoken'],
            'fraud' => [
                'token' => $this->args['fraud_token'],
                'service_id' => $this->args['fraud_service_id'],
                'mode' => 'passive',
                'data' => [
                    'transaction' => [
                        'billing' => [
                            'customerEmailAddress' => $this->args['email'] ?? ''
                        ]
                    ]
                ]
            ]
        ];

        $charge = SDKAdapterService::getInstance()->createCharge($chargeArgs);

        if (!empty($charge['error']) || empty($charge['resource']['data']['_id'])) {
            $message = SDKAdapterService::getInstance()->errorMessageToString($charge);
            throw new Exception(__('Can\'t charge.' . $message, PAY_DOCK_TEXT_DOMAIN));
        }

        return SDKAdapterService::getInstance()->capture([
            'charge_id' => $charge['resource']['data']['_id']
        ]);
    }
}
