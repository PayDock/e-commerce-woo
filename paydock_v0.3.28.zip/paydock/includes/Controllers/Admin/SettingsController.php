<?php

namespace Paydock\Controller\Admin;

class SettingsController
{

}
