import walletsForm from "../includes/wallets-form";

walletsForm(
    'google-pay',
    'Paydock Google Pay',
    'paydockWalletGooglePayButton',
    [
        'first_name',
        'last_name',
        'email',
        'address_1',
        'city',
        'state',
        'country',
        'postcode',
    ]
);

