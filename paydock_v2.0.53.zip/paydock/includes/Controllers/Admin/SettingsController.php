<?php

namespace Paydock\Controllers\Admin;

class SettingsController {

}
