jQuery('.power-board-active-hidden-settings').hide();
