<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly ?>
<style>
	.refund-items,
	.order_refund {
		display: none !important;
	}
</style>
