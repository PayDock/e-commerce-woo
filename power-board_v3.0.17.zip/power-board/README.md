=== PowerBoard for WooCommerce ===

Contributors: PowerBoard
Tags: WooCommerce, e-commerce, WordPress
Requires at least: 5.6
Tested up to: 6.2
Stable tag: 3.0.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

PowerBoard for WooCommerce enhances your WooCommerce store with advanced features and functionalities.

## Description

PowerBoard for WooCommerce is a powerful plugin designed to extend the capabilities of your WooCommerce store. 
With this plugin, you can easily manage and optimize your e-commerce operations, providing a seamless experience for both store owners and customers.
this plugin allows you to use such payment methods as: GooglePay, ApplePay, Afterpay, PayPal, Visa etc.

## Requirements

To install and configure the PowerBoard plugin, ensure your system meets the following requirements:

- **Web Server**: Nginx
- **PHP**: Version 8.1
- **Database**: MySQL version 8.0 or greater OR MariaDB 11.1
- **HTTPS**: Support for HTTPS (SSL certificate)
- **PHP Memory Limit**: 256MB
- **PHP Extensions**: curl, gd2, mbstring, xml, json, and zip

## Installation Steps

1. **Download the Plugin**:
    - Download the zip file with the plugin from the following link: [PowerBoard Plugin](https://github.com/PowerBoard/jsp-woocommerce/tree/main)

2. **Upload and Activate the Plugin**:
    - Navigate to `WordPress Dashboard -> Plugins -> Add New -> Upload Plugin`.
    - Upload the downloaded zip file.
    - Activate the plugin.

3. **Watch the Video Tutorial**:
    - For step-by-step guidance, watch the video tutorial: [Video Tutorial](https://www.loom.com/share/e3baad357d4444c6967ef4b96377784b?sid=4f21b0af-43f2-4081-9ce7-76bf946fa535).

4. **WordPress Admin User Credentials**:
    - To get the WordPress admin user credentials, click [here](https://jetsoftpro.atlassian.net/wiki/spaces/Paydoc/pages/2607448306/Installing+plugin+the+first+time).

## Third Party API and libraries

this plugin provides the ability to use payment methods through the PowerBoard API:
* for sandbox https://api.preproduction.powerboard.commbank.com.au/v1/
* for live https://api.powerboard.commbank.com.au/v1/

We also use a PowerBoard widget to implement front-end features ([More here](https://developer.powerboard.commbank.com.au/reference/powerboard-widget))

## Source

This plugin contains compile and non compile js code, if you need customize something. Code that need compile for working with woocommerce block in `/resource` path.
In root dir you can find `webpack.config.js` file, its default config for compile front-end js, but you can use it as a starting point to create your own configuration.
Also we use helper code that not need compile what contained in assets path.

## License

This plugin is licensed under the GPLv2 (or later) license. For more information, please visit [GPLv2 License](https://www.gnu.org/licenses/gpl-2.0.html).

## Support

For any issues or further assistance, please contact our support team or visit our documentation page.

Thank you for choosing PowerBoard for WooCommerce!
